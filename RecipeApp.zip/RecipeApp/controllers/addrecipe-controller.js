
let connection = require('../config');
// cryptr = new Cryptr('myTotalySecretKey');
const path = require('path');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const multer=require('multer');
const storage= multer.diskStorage({
    destination:'./uploads/',
    filename:function (req,file, cb) {
        cb(null,file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
});
const upload= multer({
    storage:storage,
    limits:{fileSize:1024*1024*5},
    fileFilter:function(rweq, file, cb){
        checkFileType(file, cb);
    }
}).single('icon');
function checkFileType(file, cb) {
//allowed extensions
    const filetypes=/jpeg|png|gif|jpg/;
    const extname =filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype=filetypes.test(file.mimetype);
    if(mimetype && extname){
        return cb(null,true);
    }
    else{
        cb('Error: images only');
    }
}
module.exports.addrecipe=function(req,res){
    upload(req, res, (err)=> {
        if(err)
        {
            res.render('index', {
                msg: err,
                title:'Image  Upload',
                hd:'Image Upload'
            });

        }
        else {
            if(req.file==undefined)
            {res.render('index',{
                    msg:'Error:No file selected of upload!',
                    title:'Image  Upload',
                    hd:'Image Upload'
                } );
            }
            else {
                console.log(req.file);
                let recipes = {
                    "name": req.body.name,
                    "cusine": req.body.cusine,
                    "catname": req.body.catname,
                    "source_id": req.body.source_id,
                    "description": req.body.description,
                    "temperature": req.body.temperature,
                    "videourl": req.body.videourl,
                    "cookingtime": req.body.cookingtime,
                    "preparationtime": req.body.preparationtime,
                    "servings": req.body.servings,
                    "ingredients": req.body.ingredients,
                    "icon": req.file.path
                }
                connection.query('INSERT INTO recipe SET ?', recipes, function (error, results, fields) {
                    if (error) {
                        res.json({
                            status: false,
                            message: 'there are some error with query' + error,
                        })
                    } else {
                        res.render('dashboard', {
                            title: 'Recipe|App',
                            hd: 'Add Recipe'
                            //users : rows
                        });
                    }
                });
            } }
    });

}