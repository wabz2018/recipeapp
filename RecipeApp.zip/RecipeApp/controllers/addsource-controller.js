require("express");
let connection = require('../config');
// cryptr = new Cryptr('myTotalySecretKey');
const path = require('path');
const ejs = require('ejs');
const bodyParser = require('body-parser');
const multer=require('multer');
const storage= multer.diskStorage({
    destination:'./uploads/',
    filename:function (req,file, cb) {
        cb(null,file.fieldname + '-' + Date.now() + path.extname(file.originalname))
    }
});
const upload= multer({
    storage:storage,
    limits:{fileSize:1024*1024*5},
    fileFilter:function(rweq, file, cb){
        checkFileType(file, cb);
    }
}).single('productimage');
function checkFileType(file, cb) {
//allowed extensions
    const filetypes=/jpeg|png|gif|jpg/;
    const extname =filetypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype=filetypes.test(file.mimetype);
    if(mimetype && extname){
        return cb(null,true);
    }
    else{
        cb('Error: images only');
    }
}
module.exports.addsource=function(req,res){
    upload(req, res, (err)=> {
        if(err)
        {
            res.render('index', {
                msg: err,
                title:'Image  Upload',
                hd:'Image Upload'
            });

        }
        else {
            if(req.file==undefined)
            {res.render('index',{
                    msg:'Error:No file selected of upload!',
                    title:'Image  Upload',
                    hd:'Image Upload'
                } );
            }
            else {
                console.log(req.file);
                let sources = {
                    "sourcename": req.body.sourcename,
                    "chefname": req.body.chefname,
                    "fblink": req.body.fblink,
                    "ytlink": req.body.ytlink,
                    "inlink": req.body.inlink,
                    "chefdetails": req.body.chefdetails,
                    "sourceurl": req.body.sourceurl,
                    "imageurl": req.file.path
                }
                connection.query('INSERT INTO sources SET ?', sources, function (error, results, fields) {
                    if (error) {
                        res.json({
                            status: false,
                            message: 'there are some error with query' + error,
                        })
                    } else {
                        res.render('dashboard', {
                            title: 'Recipe|App',
                            hd: 'Add  Source'
                            //users : rows
                        });
                    }
                });
            } }
    });

}